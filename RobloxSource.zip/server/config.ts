
export const config = {
  SESSION_SECRET: "your-secret-key-change-this-in-production",
};
